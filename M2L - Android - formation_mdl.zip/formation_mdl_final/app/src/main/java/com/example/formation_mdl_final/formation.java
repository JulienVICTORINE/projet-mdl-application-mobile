package com.example.formation_mdl_final;

public class formation
{
    private int numFormation;
    private String libelle;
    private int nbCredit;
    private int numNiveauFormation;
    private int numTypeFormation;

    public formation(int numF, String nom, int nbCredit, int numNivF, int numTypeF)
    {
        this.numFormation = numF;
        this.libelle = nom;
        this.nbCredit = nbCredit;
        this.numNiveauFormation = numNivF;
        this.numTypeFormation = numTypeF;
    }

    public int getNumFormation()
    {
        return numFormation;
    }

    public String getLibelle()
    {
        return libelle;
    }

    public int getNbCredit()
    {
        return nbCredit;
    }

    public int getNumNiveauFormation()
    {
        return numNiveauFormation;
    }

    public int getNumTypeFormation()
    {
        return numTypeFormation;
    }



}
