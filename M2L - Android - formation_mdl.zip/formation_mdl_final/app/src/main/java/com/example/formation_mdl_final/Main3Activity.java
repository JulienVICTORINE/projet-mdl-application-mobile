package com.example.formation_mdl_final;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Main3Activity extends AppCompatActivity {
    Button btnListFormation;
    Button btnListFormationUnType;
    Button btnListFormationUnNiv;
    Button btnListFormationParLigue;
    Button btnListFormationUneLigue;

    private ArrayList<formation> listForm;
    private MyAppAdapter myAppAdapter;
    private ListView listView;
    private boolean success = false;

    private static final String DB_URL = "jdbc:mysql://192.168.1.16/maisondesligues"; //"jdbc:mysql://DATABASE_IP/DATABSE_NAME
    private static final String USER = "root";
    private static final String PASSWORD = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Button btnListFormation = (Button) findViewById(R.id.btnListFormation);
        btnListFormation.setOnClickListener(new View.OnClickListener() { // Notre classe anonyme
            public void onClick(View view) {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent = new Intent(Main3Activity.this, listFormation.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });

        Button btnListFormationUnType = (Button) findViewById(R.id.btnListFormationUnType);
        btnListFormationUnType.setOnClickListener(new View.OnClickListener() { // Notre classe anonyme
            public void onClick(View view) {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent = new Intent(Main3Activity.this, listFormationUnType.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });

        Button btnListFormationUnNiv = (Button) findViewById(R.id.btsListFormationUnNiv);
        btnListFormationUnNiv.setOnClickListener(new View.OnClickListener() { // Notre classe anonyme
            public void onClick(View view) {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent = new Intent(Main3Activity.this, listFormationUnNiv.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });

        Button btnListFormationParLigue = (Button) findViewById(R.id.btnListFormationParLigue);
        btnListFormationParLigue.setOnClickListener(new View.OnClickListener() { // Notre classe anonyme
            public void onClick(View view) {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent = new Intent(Main3Activity.this, listFormationParLigue.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });

        Button btnListFormationUneLigue = (Button) findViewById(R.id.btnListFormationUneLigue);
        btnListFormationUneLigue.setOnClickListener(new View.OnClickListener() { // Notre classe anonyme
            public void onClick(View view) {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent = new Intent(Main3Activity.this, listFormationUneLigue.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });


        listView = (ListView) findViewById(R.id.listFormation); //Déclaration d'une liste
        listForm = new ArrayList<formation>(); //Initialisation d'une arrayList

        //Appel Async Task
        SyncData orderData = new SyncData();
        orderData.execute();
    }

    //Async Task has three overrided methods
    private class SyncData extends AsyncTask<String, String, String>
    {
        String msg = "Internet/DB_Credentials/Windows_Firewall_TurnOn Error, See Android Monitor in the bottom for details !";
        ProgressDialog progress;

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(Main3Activity.this, "Synchronisation",
                    "Chargement de la liste ! S'il vous plaît, attendez...", true);

        }

        @Override
        // Connectez-vous à la base de données, écrivez les requêtes et ajoutez des éléments dans le tableau
        protected String doInBackground(String... strings)
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
                if (conn == null) {
                    success = false;
                } else {
                    // Changer la requête ci-dessous en fonction de votre base de données
                    String query = "SELECT * FROM formation";
                    Statement stmt = conn.createStatement();
                    ResultSet rs = (ResultSet) stmt.executeQuery(query);
                    if (rs != null) // Si ResultSet n'est pas null, j'ajoite des éléments à itemArraylist à l'aide de la classe crée
                    {
                        while (rs.next()) {
                            try {
                                listForm.add(new formation(rs.getInt("numFormation"), rs.getString("libelle"), rs.getInt("nbCredit"), rs.getInt("numNiveauFormation"), rs.getInt("numTypeFormation")));
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        msg = "Trouvé";
                        success = true;
                    } else {
                        msg = "Données non trouvées";
                        success = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Writer writer = new StringWriter();
                e.printStackTrace(new PrintWriter(writer));
                msg = writer.toString();
                success = false;
            }
            return msg;
        }

        @Override
        protected void onPostExecute(String msg) //Dialogue de processus de suppression, indiquant une erreur et configuration de ma liste
        {
            progress.dismiss();
            Toast.makeText(Main3Activity.this, msg + "", Toast.LENGTH_LONG).show();
            if (success == false) {
            } else {
                try {
                    myAppAdapter = new MyAppAdapter(listForm, Main3Activity.this);
                    listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                    listView.setAdapter(myAppAdapter);
                } catch (Exception ex) {

                }
            }

        }
    }

    public class MyAppAdapter extends BaseAdapter {
        public class ViewHolder {
            TextView textName;
        }

        public List<formation> parkingList;

        public Context context;
        ArrayList<formation> arrayList;

        private MyAppAdapter(List<formation> apps, Context context) {
            this.parkingList = apps;
            this.context = context;
            arrayList = new ArrayList<formation>();
            arrayList.addAll(parkingList);
        }

        @Override
        public int getCount() {
            return parkingList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        @Override
        // gonfler la mise en page et initialiser les widgets
        public View getView(final int position, View convertView, ViewGroup parent)
        {
            View rowView = convertView;
            ViewHolder viewHolder = null;
            if (rowView == null) {
                LayoutInflater inflater = getLayoutInflater();
                rowView = inflater.inflate(R.layout.activity_list_formation, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.textName = (TextView) rowView.findViewById(R.id.btnListFormation);
                rowView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            // Ici la mise en place des noms
            viewHolder.textName.setText(parkingList.get(position).getLibelle() + "");

            return rowView;
        }
    }
}