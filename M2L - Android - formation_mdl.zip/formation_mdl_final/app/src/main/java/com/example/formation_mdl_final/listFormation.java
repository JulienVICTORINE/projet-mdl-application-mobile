package com.example.formation_mdl_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class listFormation extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_formation);

        Button btnAcceuil = (Button)findViewById(R.id.btnListFormation);
        btnAcceuil.setOnClickListener(new View.OnClickListener()
        {
            // Notre classe anonyme
            public void onClick(View view)
            {
                // et sa méthode !
                //on creer une nouvelle intent on definit la class de depart ici this et la class d'arrivé ici SecondActivite
                Intent intent=new Intent(listFormation.this, Main3Activity.class);
                //on lance l'intent, cela a pour effet de stoper l'activité courante et lancer une autre activite ici SecondActivite
                startActivity(intent);
            }
        });
    }
}
